class AppConfig {
  
}
